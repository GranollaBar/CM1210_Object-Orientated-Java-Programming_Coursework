import java.util.*;

//sorts result in order to return all values simultaneously
public class SortResult {
    public List<String> sortedList;
    public int numberOfSwaps;
    public int timeTakenNanoSeconds;
}
